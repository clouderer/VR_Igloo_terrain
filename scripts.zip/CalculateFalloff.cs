using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class CalculateFalloff
{
    public static float EvaluateFalloff (int x, int z, int size_x, int size_z, float flatness, float steepness)
    {
        float xVal = (x / (float)size_x) * 2 - 1; 
        float zVal = (z / (float)size_z) * 2 - 1; 

        float value = Mathf.Sqrt(xVal * xVal + zVal * zVal);

        return Mathf.Pow(value, flatness) / (Mathf.Pow(value, flatness) + Mathf.Pow(steepness - steepness * value, flatness));
    }
}
