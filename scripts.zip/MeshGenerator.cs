using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshCollider))]
public class MeshGenerator : MonoBehaviour
{
    Mesh mesh; 
    MeshCollider meshCollider;
    Vector3[] vertices;

    Color[] colors; 
    int[] triangles;

    //Terrain size
    public int size_x = 255; 
    public int size_z = 255;

    //Fractal Brownian Motion parameters
    public float amplitude = 5.0f; 
    public float frequency = 0.3f; 
    public int numOctaves = 4; 

    //Scaling and Transformation
    public float noiseScale = 0.05f;
    public float heightScale = 10.0f;

    //Falloff parameters
    public float flatness = 3.0f;
    public float steepness = 2.0f;

    //Gradient
    public Gradient gradient;


    float minTerrainHeight = 0;
    float maxTerrainHeight = 0; 

    float maxPossible = 0;


/*--*/
    float FractalBrownianMotion (float x, float y, int numOctaves)
    {   float result = 0.0f;
        float amp = amplitude;
        float frq = frequency;
        maxPossible = amplitude;

        for (int octave = 0; octave < numOctaves; octave ++)
        {
            float n = amp * PerlinNoise.Noise(x * frq, y * frq);
            result +=n;

            amp *= 0.5f;
            frq *= 2.0f;
            maxPossible += amp;
        }
        return result;
    }
/*--*/

    void Start() {
        mesh = new Mesh();   
        GetComponent<MeshFilter>().mesh = mesh; 

        meshCollider = GetComponent<MeshCollider>();

        CreateShape();
        UpdateMesh();
    }

    void CreateShape() {
        vertices = new Vector3 [(size_x + 1) * (size_z + 1)];

        //float maxPossible = amplitude * 1.875f; //1,875 je 1 + 0,5 + 0,25 + 0,125 neboli amplituda na 0 + amplituda na ...

        for (int z = 0, i = 0; z <= size_z; z++) {
            for (int x = 0; x <= size_x; x++){

                float noiseHeight = FractalBrownianMotion(x * noiseScale, z * noiseScale, numOctaves);
                noiseHeight = (noiseHeight + maxPossible)/(2.0f * maxPossible);

                float falloff = CalculateFalloff.EvaluateFalloff(x, z, size_x, size_z, flatness, steepness); 

                float y = Mathf.Clamp01(noiseHeight - falloff) * heightScale; 
                vertices[i] = new Vector3 (x, y, z); 

                if (y > maxTerrainHeight) maxTerrainHeight = y; 
                if (y < minTerrainHeight) minTerrainHeight = y;                

                i++;
            }
        }

        int vert = 0, tris = 0;
        triangles = new int[size_x * size_z * 6];

        for (int z = 0; z < size_z; z++) {
            for (int x = 0; x < size_x; x++) {
                triangles[0 + tris] = 0 + vert; 
                triangles[1 + tris] = size_x + 1 + vert;
                triangles[2 + tris] = 1 + vert;
                triangles[3 + tris] = 1 + vert; 
                triangles[4 + tris] = size_x + 1 + vert; 
                triangles[5 + tris] = size_x + 2 + vert;

                tris += 6;
                vert++;
            }
            vert++;
        }

        colors = new Color[vertices.Length]; 

        for (int z = 0, i = 0; z <= size_z; z++) {
            for (int x = 0; x <= size_x; x++){
                float height = Mathf.InverseLerp(minTerrainHeight, maxTerrainHeight, vertices[i].y);
                colors[i] = gradient.Evaluate(height);
                if(vertices[i].y == 0) colors[i] = new Color(0.337f, 0.518f, 0.859f);
                
                i++;
            }
        }

    }

    void UpdateMesh() {
        mesh.Clear();

        mesh.vertices = vertices; 
        mesh.triangles = triangles;
        mesh.colors = colors;

        mesh.RecalculateNormals();
        mesh.RecalculateBounds();

        meshCollider.sharedMesh = null; 
        meshCollider.sharedMesh = mesh;
    }
}
