using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;


public class PerlinNoise
{
    //Static permutation table
    //It is used to generate the terrain
    private static int[] permutationTable = //GeneratePermutationTable(seed);
    {
        151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,
        23,190, 6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,88,237,149,56,
        87,174,20,125,136,171,168, 68,175,74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,
        60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54, 65,25,63,161, 1,216,80,73,209,76,132,
        187,208, 89,18,169,200,196,135,130,116,188,159,86,164,100,109,198,173,186, 3,64,52,217,226,250,
        124,123,5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,223,183,
        170,213,119,248,152, 2,44,154,163,70,221,153,101,155,167, 43,172,9,129,22,39,253, 19,98,108,110,
        79,113,224,232,178,185,112,104,218,246,97,228,251,34,242,193,238,210,144,12,191,179,162,241,81,
        51,145,235,249,14,239,107,49,192,214, 31,181,199,106,157,184,84,204,176,115,121,50,45,127,4,150,
        254,138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180
    }; 

    private static int[] p;

    //Generating on call
    static PerlinNoise()
    {
        //Copying/doubling the permutation table to avoid reaching out of bounds when getting hash codes for individual blocks. 
        p = new int[512]; 
        for (int i = 0; i < 512; i++)
            p[i] = permutationTable[i % 256]; 
    }

    //Ease in function.
    private static float Fade(float t)
    {
        return ((6*t - 15)*t +10)*t*t*t;
    }

    //Linear interpolation function
    //a is the start point
    //b is the end point 
    //t is the interpolation factor
    private static float Lerp(float t, float a, float b)
    {
        return a + t*(b-a);
    }

    //Function which will assign constant vectors and calculate the dot product for each of the corners directly;
    private static float Gradient(int hash, float x, float y)
    {
        int h = hash & 7; // lze ziskat az 8 cisel -> 8 smeru 
        float u = h < 4 ? x : y; 
        float v = h < 4 ? y : x; 

        return ((h&1) == 0 ? u : -u) + ((h&2) == 0 ? v : -v); 
    }

    public static float Noise(float x, float y)
    {

        //Souradnice bunky mrizky
        int X = Mathf.FloorToInt(x) & 255;
        int Y = Mathf.FloorToInt(y) & 255; 

        //Relativni pozice pixelu vuci jeho bloku
        float xf = x - Mathf.Floor(x);  
        float yf = y - Mathf.Floor(y);  

        //Hodnoty pouzite jako pomer v interpolacni funkci
        float u = Fade(xf); 
        float v = Fade(yf);

        int a = p[p[X+1]+Y+1]; // (x+1,y+1) -- hash pro horni pravy vrchol
        int b = p[p[X]+Y+1];   // (x,y+1)   -- hash pro horni levy vrchol
        int c = p[p[X+1]+Y];   // (x+1,y)   -- hash pro dolni pravy vrchol
        int d = p[p[X]+Y];   // (x,y+1)   -- hash pro dolni levy vrchol

        float x1 = Lerp (u, Gradient(d, xf , yf), Gradient(c, xf-1, yf)); 
        float x2 = Lerp (u, Gradient(b, xf, yf-1), Gradient(a, xf-1, yf-1));

        return (Lerp(v,x1,x2) + 1.0f ) * 0.5f;
    }
 }
